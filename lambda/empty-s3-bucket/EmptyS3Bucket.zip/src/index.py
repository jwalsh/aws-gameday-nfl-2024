import boto3
import cfnresponse
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info('event: {}'.format(event))
    logger.info('context: {}'.format(context))

    if event['RequestType'] == 'Delete':
        try:
            AssetsBucketName = (event['ResourceProperties']['S3Bucket'])
            s3 = boto3.resource('s3')
            logger.info('S3 Object initialized')
            bucket = s3.Bucket(AssetsBucketName)
            logger.info('S3 bucket: ' + AssetsBucketName)
            bucket.objects.all().delete()
            cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData={}, reason='S3 bucket emptied: ' + AssetsBucketName )
        except Exception as e:
            logger.error(e, exc_info=True)
            cfnresponse.send(event, context, cfnresponse.FAILED, responseData={}, reason=str(e))
    else:
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData={}, reason='No action to take')
