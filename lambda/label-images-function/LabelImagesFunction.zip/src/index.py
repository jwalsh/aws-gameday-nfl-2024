import base64
import json
import os

import boto3

IMAGE_LABEL_TABLE = os.environ["IMAGE_LABEL_TABLE"]

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(IMAGE_LABEL_TABLE)


def lambda_handler(event, _):
    """Extract image labels from NFL game images and store them in DynamoDB

    Workflow:
    - Retrieve image from S3
    - #TODO: Extract image labels from image
    - Store image labels in DynamoDB
    """

    # Extract the s3 object details from the SQS message
    record = event["Records"][0]
    body = json.loads(record["body"])
    message = json.loads(body["Message"])
    s3_bucket = message["s3_bucket"]
    s3_object_key = message["s3_object_key"]

    # Retrieve the object (image) from S3
    encoded_image = s3_client.get_object(Bucket=s3_bucket, Key=s3_object_key)[
        "Body"
    ].read()
    encoded_image = base64.b64encode(encoded_image).decode("utf-8")

    ##################################################################################
    # TODO: Implement awesome solution here using Amazon Bedrock
    play = ""  # TODO: replace with the actual play from the image
    teams = [""]  # TODO: replace with the actual teams from the image
    ##################################################################################

    table.put_item(
        Item={
            "s3_object_key": s3_object_key,
            "play": play,
            "teams": teams,
        },
    )
