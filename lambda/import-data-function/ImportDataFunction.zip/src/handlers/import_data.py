import csv
import os
from collections import defaultdict

import boto3
import cfnresponse

ASSETS_BUCKET = os.environ["ASSETS_BUCKET"]
ASSETS_BUCKET_PREFIX = os.environ["ASSETS_BUCKET_PREFIX"]
NFL_PLAYER_DATA_TABLE = os.environ["NFL_PLAYER_DATA_TABLE"]
CSV_FILENAME = "basic_stats.csv"
HEADERS = [
    "player_id",
    "height",
    "weight",
    "birth_date",
    "college",
    "position",
    "name",
]
PK_INDEX = HEADERS.index("player_id")  # Index of Player Id column
NAME_INDEX = HEADERS.index("name")  # Index of Name column
POSITION_INDEX = HEADERS.index("position")
COLLEGE_INDEX = HEADERS.index("college")


s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(NFL_PLAYER_DATA_TABLE)


def write_batch(items):
    print(f"Writing batch of {len(items)} to {NFL_PLAYER_DATA_TABLE} DynamoDB table")
    with table.batch_writer() as batch:
        for item in items:
            batch.put_item(Item=item)


def get_csv_file():
    object_key = ASSETS_BUCKET_PREFIX + CSV_FILENAME
    print(f"Retrieving CSV file from s3://{ASSETS_BUCKET}/{object_key}")
    response = s3.get_object(Bucket=ASSETS_BUCKET, Key=object_key)
    return response["Body"].read().decode("utf-8")


def import_data():
    csv_data = get_csv_file()
    csv_reader = csv.reader(csv_data.splitlines())
    next(csv_reader)  # Skip headers

    items = []
    index = defaultdict(list)

    # Create player detail items
    for row in csv_reader:
        item = {}
        index_val = row[NAME_INDEX][0].lower()
        index[index_val].append(
            {
                "id": row[PK_INDEX],
                "position": row[POSITION_INDEX],
                "college": row[COLLEGE_INDEX],
                "name": row[NAME_INDEX],
            }
        )
        for i, value in enumerate(row):
            if i == PK_INDEX:
                item["pk"] = value
                item["sk"] = value
            else:
                if not value:
                    item[HEADERS[i]] = None
                else:
                    item[HEADERS[i]] = value
        items.append(item)

    # Create index items
    for char, char_index in index.items():
        items.append({"pk": "player_index", "sk": char, "players": char_index})

    write_batch(items)
    print("Successfully imported data")


def handler(event, context):
    request_type = event["RequestType"]
    try:
        if request_type in ("Create", "Update"):
            print("Create request received, importing data")
            import_data()
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
    except Exception as e:
        print(f"Failed to process with error: {e}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {})


if __name__ == "__main__":
    import_data()
